import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/ControlledInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0eb6d985"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/ControlledInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/frontend/styles/main.css";
export function ControlledInput({
  value,
  setValue,
  onKeyDown,
  ariaLabel
}) {
  return /* @__PURE__ */ jsxDEV("input", { type: "text", className: "repl-command-box", value, placeholder: "Enter command here!", onChange: (ev) => setValue(ev.target.value), onKeyDown, "aria-label": ariaLabel }, void 0, false, {
    fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/ControlledInput.tsx",
    lineNumber: 25,
    columnNumber: 10
  }, this);
}
_c = ControlledInput;
var _c;
$RefreshReg$(_c, "ControlledInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/ControlledInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEJJO0FBOUJKLE9BQU8sb0JBQW9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBcUJwQixnQkFBU0EsZ0JBQWdCO0FBQUEsRUFDOUJDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBRW9CLEdBQUc7QUFFdkIsU0FDRSx1QkFBQyxXQUNDLE1BQUssUUFDTCxXQUFVLG9CQUNWLE9BQ0EsYUFBWSx1QkFDWixVQUFXQyxRQUFPSCxTQUFTRyxHQUFHQyxPQUFPTCxLQUFLLEdBQzFDLFdBQ0EsY0FBWUcsYUFQZDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBUUM7QUFFTDtBQUFDRyxLQW5CZVA7QUFBZSxJQUFBTztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ29udHJvbGxlZElucHV0IiwidmFsdWUiLCJzZXRWYWx1ZSIsIm9uS2V5RG93biIsImFyaWFMYWJlbCIsImV2IiwidGFyZ2V0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb250cm9sbGVkSW5wdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9tYWluLmNzc1wiO1xuaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcblxuXG4vKipcbiAqIFByb3BzIGZvciB0aGUgQ29udHJvbGxlZElucHV0IGNvbXBvbmVudC5cbiAqL1xuaW50ZXJmYWNlIENvbnRyb2xsZWRJbnB1dFByb3BzIHtcbiAgdmFsdWU6IHN0cmluZztcbiAgc2V0VmFsdWU6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPHN0cmluZz4+O1xuICBhcmlhTGFiZWw6IHN0cmluZztcbiAgb25LZXlEb3duPzogKGU6IFJlYWN0LktleWJvYXJkRXZlbnQpID0+IHZvaWQ7IC8vbmV3IG9wdGlvbmFsIHByb3AgdG8gaGFuZGxlIHByZXNzaW5nIHN1Ym1pdCBmcm9tIGNvbnRyb2xsZWQgaW5wdXRcbn1cblxuXG5cbi8qKlxuICogQSBjb250cm9sbGVkIGlucHV0IGNvbXBvbmVudCBjb3JyZXNwb25kaW5nIHRvIHVzZXIncyBpbnB1dCBpbiB0aGUgY29tbWFuZCBib3guXG4gKiBBbGxvd3MgZm9yIGl0cyB2YWx1ZSB0byBiZSBtYW5hZ2VkIGV4dGVybmFsbHkuXG4gKiBAcGFyYW0ge0NvbnRyb2xsZWRJbnB1dFByb3BzfSBwcm9wcyAtIFRoZSBwcm9wcyBmb3IgdGhlIENvbnRyb2xsZWRJbnB1dCBjb21wb25lbnQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBDb250cm9sbGVkSW5wdXQoe1xuICB2YWx1ZSxcbiAgc2V0VmFsdWUsXG4gIG9uS2V5RG93bixcbiAgYXJpYUxhYmVsLFxuXG59OiBDb250cm9sbGVkSW5wdXRQcm9wcykge1xuXG4gIHJldHVybiAoXG4gICAgPGlucHV0XG4gICAgICB0eXBlPVwidGV4dFwiXG4gICAgICBjbGFzc05hbWU9XCJyZXBsLWNvbW1hbmQtYm94XCJcbiAgICAgIHZhbHVlPXt2YWx1ZX1cbiAgICAgIHBsYWNlaG9sZGVyPVwiRW50ZXIgY29tbWFuZCBoZXJlIVwiXG4gICAgICBvbkNoYW5nZT17KGV2KSA9PiBzZXRWYWx1ZShldi50YXJnZXQudmFsdWUpfVxuICAgICAgb25LZXlEb3duPXtvbktleURvd259XG4gICAgICBhcmlhLWxhYmVsPXthcmlhTGFiZWx9XG4gICAgPjwvaW5wdXQ+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy96ZHppbG93c2thL0Rlc2t0b3AvdW5pdmVyc2l0eS95ZWFyIDIvY3MwMzIwL3JlcGwtanpkemlsb3ctcHJsYWtzaG0vcmVwbC9zcmMvZnJvbnRlbmQvY29tcG9uZW50cy9Db250cm9sbGVkSW5wdXQudHN4In0=