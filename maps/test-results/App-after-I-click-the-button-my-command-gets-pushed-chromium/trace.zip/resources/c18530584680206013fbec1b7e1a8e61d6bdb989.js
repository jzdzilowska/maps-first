import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/REPLInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0eb6d985"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/REPLInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/frontend/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=0eb6d985"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/frontend/components/ControlledInput.tsx";
import { handleMockLoad, handleMockView, handleMockSearch, handleMockBroadband } from "/src/frontend/components/MockedREPLFunctions.tsx";
import __vite__cjsImport7_react from "/node_modules/.vite/deps/react.js?v=0eb6d985"; const useEffect = __vite__cjsImport7_react["useEffect"];
const commandRegistry = /* @__PURE__ */ new Map();
function registerCommand(command, func) {
  commandRegistry.set(command, func);
}
export function REPLInput(props) {
  _s();
  const [commandString, setCommandString] = useState("");
  const [count, setCount] = useState(0);
  const {
    mode,
    setMode,
    history,
    setHistory,
    commandResultMap,
    updateCommandResult,
    ariaLabel
  } = props;
  const handleRegister = async (args) => {
    if (args.length !== 2) {
      return "Invalid usage of 'register' command. Usage: register <commandName> <functionToExecute>";
    }
    const commandName = args[0];
    const toExecute = args[1];
    if (commandRegistry.has(commandName)) {
      return "Command: " + commandName + " is already registered";
    } else {
      registerCommand(commandName, eval(toExecute));
      return "Command registered: " + commandName;
    }
  };
  const handleMode = async (args2) => {
    const validModes = ["brief", "verbose"];
    if (args2.length !== 1) {
      return "Invalid usage of 'mode' command. Usage: mode <newMode>";
    }
    if (validModes.includes(args2[0])) {
      setMode(args2[0]);
      return "Mode changed to " + args2[0];
    } else {
      return "Invalid mode: " + args2[0] + ". Use brief or verbose";
    }
  };
  const handleLoad = async (args2) => {
    if (args2.length !== 1) {
      return "Invalid usage of 'load' command. Usage: load <URL>";
    }
    const filepath = args2[0].trim();
    try {
      const response = await fetch(`http://localhost:3232/loadcsv?filepath=repl/src/backend/${filepath}`);
      if (response.ok) {
        const data = await response.json();
        const resultMessage = data.result === "success" ? "File " + filepath + " loaded successfully" : data.error_message;
        return resultMessage;
      } else
        return "Failed to fetch data from the backend";
    } catch (error) {
      return "An error ocurred while loading the file: " + error;
    }
  };
  const handleView = async (args2) => {
    if (args2.length !== 0) {
      return "Invalid usage of 'view' command. Usage: view";
    }
    try {
      const response = await fetch("http://localhost:3232/viewcsv");
      if (response.ok) {
        const data = await response.json();
        const resultMessage = data.result === "success" ? data.data : data.error_message;
        return resultMessage;
      } else
        return "Failed to fetch data from the backend";
    } catch (error) {
      return "An error occurred while viewing the file: " + error;
    }
  };
  const handleSearch = async (args2) => {
    if (args2.length !== 3) {
      return "Invalid search command. Usage: search <hasHeaders> <value> <columnId>";
    }
    const hasHeaders = args2[0];
    const value = args2[1].includes("%") ? args2[1].replace("%", "%25").replace(/_/g, " ") : args2[1].replace(/_/g, " ");
    const columnId = args2[2].replace(/_/g, " ");
    try {
      const response = await fetch(`http://localhost:3232/searchcsv?headers=${hasHeaders}&value=${value}&colid=${columnId}`);
      if (response.ok) {
        const data = await response.json();
        const resultMessage = data.result === "success" ? data.data : data.error_message;
        return resultMessage;
      } else
        return "Failed to fetch data from the backend";
    } catch (error) {
      return "An error occurred while searching through the file: " + error;
    }
  };
  const handleBroadband = async (args2) => {
    if (args2.length !== 2) {
      return "Invalid broadband retrieval command. Usage: broadband <state> <county>";
    }
    const state = args2[0].replace(/_/g, " ");
    const county = args2[1].replace(/_/g, " ");
    try {
      const response = await fetch(`http://localhost:3232/broadband?state=${state}&county=${county}`);
      if (response.ok) {
        const data = await response.json();
        const resultMessage = data.result === "success" ? `time of retrieval: ${data.date_time} broadband access percent: ${data.broadband_access_percent}` : data.error_message;
        return resultMessage;
      } else
        return "Failed to fetch data from the backend";
    } catch (error) {
      return "An error occurred while fetching broadband data: " + error;
    }
  };
  useEffect(() => {
    registerCommand("register", handleRegister);
    registerCommand("mode", handleMode);
    registerCommand("load", handleLoad);
    registerCommand("view", handleView);
    registerCommand("search", handleSearch);
    registerCommand("broadband", handleBroadband);
    registerCommand("mockload", handleMockLoad);
    registerCommand("mockview", handleMockView);
    registerCommand("mocksearch", handleMockSearch);
    registerCommand("mockbroadband", handleMockBroadband);
  }, []);
  async function executeCommand(commandName2, args2) {
    const func = commandRegistry.get(commandName2);
    if (func) {
      try {
        const result = await func(args2);
        return result;
      } catch (error) {
        return `Error executing command. ${error}`;
      }
    } else {
      return `Command not found: ${commandName2}. Input "register <commandName> <function>" to register new command`;
    }
  }
  function handleSubmit(commandString2) {
    const trimmedCommand = commandString2.trim();
    if (trimmedCommand === "") {
      alert("Command cannot be empty");
      return;
    }
    const args2 = trimmedCommand.split(/\s+/);
    executeCommand(args2[0], args2.slice(1)).then((result) => {
      updateCommandResult(commandString2, result);
      setCount(count + 1);
    });
    setCommandString("");
  }
  function handleEnterPress(e) {
    if (e.key === "Enter") {
      handleSubmit(commandString);
    }
  }
  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.key === "b" && e.ctrlKey) {
        const inputElement = document.querySelector(".repl-command-box");
        if (inputElement && inputElement instanceof HTMLInputElement)
          inputElement.focus();
      }
    };
    document.addEventListener("keydown", handleKeyPress);
    return () => {
      document.removeEventListener("keydown", handleKeyPress);
    };
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "repl-input", "aria-live": "polite", "aria-label": ariaLabel, children: [
    /* @__PURE__ */ jsxDEV("fieldset", { children: [
      /* @__PURE__ */ jsxDEV("legend", { children: "Enter a command:" }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/REPLInput.tsx",
        lineNumber: 267,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, ariaLabel: "Command Input Box to type in commands", onKeyDown: handleEnterPress }, void 0, false, {
        fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/REPLInput.tsx",
        lineNumber: 268,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/REPLInput.tsx",
      lineNumber: 266,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { onClick: () => handleSubmit(commandString), children: "Submit" }, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/REPLInput.tsx",
      lineNumber: 270,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/REPLInput.tsx",
    lineNumber: 265,
    columnNumber: 10
  }, this);
}
_s(REPLInput, "ENpYGy7RzhD7Zwuou93UyOmtyqg=");
_c = REPLInput;
var _c;
$RefreshReg$(_c, "REPLInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/REPLInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMFNROzs7Ozs7Ozs7Ozs7Ozs7OztBQTFTUixPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFHaEMsU0FBU0MsZ0JBQWdCQyxnQkFBZ0JDLGtCQUFrQkMsMkJBQ3REO0FBQ0wsU0FBU0MsaUJBQWlCO0FBSTFCLE1BQU1DLGtCQUFrQixvQkFBSUMsSUFBMEI7QUFPdEQsU0FBU0MsZ0JBQWdCQyxTQUFpQkMsTUFBb0I7QUFDNURKLGtCQUFnQkssSUFBSUYsU0FBU0MsSUFBSTtBQUNuQztBQW1CTyxnQkFBU0UsVUFBVUMsT0FBdUI7QUFBQUMsS0FBQTtBQUMvQyxRQUFNLENBQUNDLGVBQWVDLGdCQUFnQixJQUFJakIsU0FBaUIsRUFBRTtBQUM3RCxRQUFNLENBQUNrQixPQUFPQyxRQUFRLElBQUluQixTQUFpQixDQUFDO0FBQzVDLFFBQU07QUFBQSxJQUNKb0I7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUM7QUFBQUEsRUFDRixJQUFJWjtBQU1KLFFBQU1hLGlCQUErQixPQUNuQ0MsU0FDb0I7QUFDcEIsUUFBSUEsS0FBS0MsV0FBVyxHQUFHO0FBQ3JCLGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTUMsY0FBY0YsS0FBSyxDQUFDO0FBQzFCLFVBQU1HLFlBQVlILEtBQUssQ0FBQztBQUN4QixRQUFJckIsZ0JBQWdCeUIsSUFBSUYsV0FBVyxHQUFHO0FBQ3BDLGFBQU8sY0FBY0EsY0FBYztBQUFBLElBQ3JDLE9BQU87QUFDTHJCLHNCQUFnQnFCLGFBQWFHLEtBQUtGLFNBQVMsQ0FBQztBQUM1QyxhQUFPLHlCQUF5QkQ7QUFBQUEsSUFDbEM7QUFBQSxFQUNGO0FBT0EsUUFBTUksYUFBMkIsT0FBT04sVUFBb0M7QUFDMUUsVUFBTU8sYUFBYSxDQUFDLFNBQVMsU0FBUztBQUN0QyxRQUFJUCxNQUFLQyxXQUFXLEdBQUc7QUFDckIsYUFBTztBQUFBLElBQ1Q7QUFDQSxRQUFJTSxXQUFXQyxTQUFTUixNQUFLLENBQUMsQ0FBQyxHQUFHO0FBQ2hDUCxjQUFRTyxNQUFLLENBQUMsQ0FBQztBQUNmLGFBQU8scUJBQXFCQSxNQUFLLENBQUM7QUFBQSxJQUNwQyxPQUFPO0FBQ0wsYUFBTyxtQkFBbUJBLE1BQUssQ0FBQyxJQUFJO0FBQUEsSUFDdEM7QUFBQSxFQUNGO0FBTUEsUUFBTVMsYUFBMkIsT0FBT1QsVUFBb0M7QUFDMUUsUUFBSUEsTUFBS0MsV0FBVyxHQUFHO0FBQ3JCLGFBQU87QUFBQSxJQUNUO0FBQ0EsVUFBTVMsV0FBV1YsTUFBSyxDQUFDLEVBQUVXLEtBQUs7QUFDOUIsUUFBSTtBQUNGLFlBQU1DLFdBQVcsTUFBTUMsTUFDcEIsMkRBQTBESCxRQUFTLEVBQ3RFO0FBQ0EsVUFBSUUsU0FBU0UsSUFBSTtBQUNmLGNBQU1DLE9BQU8sTUFBTUgsU0FBU0ksS0FBSztBQUNqQyxjQUFNQyxnQkFDSkYsS0FBS0csV0FBVyxZQUNaLFVBQVVSLFdBQVcseUJBQ3JCSyxLQUFLSTtBQUNYLGVBQU9GO0FBQUFBLE1BQ1Q7QUFBTyxlQUFPO0FBQUEsSUFDaEIsU0FBU0csT0FBTztBQUdkLGFBQU8sOENBQThDQTtBQUFBQSxJQUN2RDtBQUFBLEVBQ0Y7QUFNQSxRQUFNQyxhQUEyQixPQUFPckIsVUFBb0M7QUFDMUUsUUFBSUEsTUFBS0MsV0FBVyxHQUFHO0FBQ3JCLGFBQU87QUFBQSxJQUNUO0FBQ0EsUUFBSTtBQUNGLFlBQU1XLFdBQVcsTUFBTUMsTUFBTSwrQkFBK0I7QUFDNUQsVUFBSUQsU0FBU0UsSUFBSTtBQUNmLGNBQU1DLE9BQU8sTUFBTUgsU0FBU0ksS0FBSztBQUNqQyxjQUFNQyxnQkFDSkYsS0FBS0csV0FBVyxZQUFZSCxLQUFLQSxPQUFPQSxLQUFLSTtBQUMvQyxlQUFPRjtBQUFBQSxNQUNUO0FBQU8sZUFBTztBQUFBLElBQ2hCLFNBQVNHLE9BQU87QUFDZCxhQUFPLCtDQUErQ0E7QUFBQUEsSUFDeEQ7QUFBQSxFQUNGO0FBTUEsUUFBTUUsZUFBNkIsT0FDakN0QixVQUNvQjtBQUNwQixRQUFJQSxNQUFLQyxXQUFXLEdBQUc7QUFDckIsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNc0IsYUFBYXZCLE1BQUssQ0FBQztBQUN6QixVQUFNd0IsUUFBUXhCLE1BQUssQ0FBQyxFQUFFUSxTQUFTLEdBQUcsSUFDOUJSLE1BQUssQ0FBQyxFQUFFeUIsUUFBUSxLQUFLLEtBQUssRUFBRUEsUUFBUSxNQUFNLEdBQUcsSUFDN0N6QixNQUFLLENBQUMsRUFBRXlCLFFBQVEsTUFBTSxHQUFHO0FBQzdCLFVBQU1DLFdBQVcxQixNQUFLLENBQUMsRUFBRXlCLFFBQVEsTUFBTSxHQUFHO0FBRTFDLFFBQUk7QUFDRixZQUFNYixXQUFXLE1BQU1DLE1BQ3BCLDJDQUEwQ1UsVUFBVyxVQUFTQyxLQUFNLFVBQVNFLFFBQVMsRUFDekY7QUFDQSxVQUFJZCxTQUFTRSxJQUFJO0FBQ2YsY0FBTUMsT0FBTyxNQUFNSCxTQUFTSSxLQUFLO0FBQ2pDLGNBQU1DLGdCQUNKRixLQUFLRyxXQUFXLFlBQVlILEtBQUtBLE9BQU9BLEtBQUtJO0FBQy9DLGVBQU9GO0FBQUFBLE1BQ1Q7QUFBTyxlQUFPO0FBQUEsSUFDaEIsU0FBU0csT0FBTztBQUNkLGFBQU8seURBQXlEQTtBQUFBQSxJQUNsRTtBQUFBLEVBQ0Y7QUFNQSxRQUFNTyxrQkFBZ0MsT0FDcEMzQixVQUNvQjtBQUNwQixRQUFJQSxNQUFLQyxXQUFXLEdBQUc7QUFDckIsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNMkIsUUFBUTVCLE1BQUssQ0FBQyxFQUFFeUIsUUFBUSxNQUFNLEdBQUc7QUFDdkMsVUFBTUksU0FBUzdCLE1BQUssQ0FBQyxFQUFFeUIsUUFBUSxNQUFNLEdBQUc7QUFFeEMsUUFBSTtBQUNGLFlBQU1iLFdBQVcsTUFBTUMsTUFDcEIseUNBQXdDZSxLQUFNLFdBQVVDLE1BQU8sRUFDbEU7QUFDQSxVQUFJakIsU0FBU0UsSUFBSTtBQUNmLGNBQU1DLE9BQU8sTUFBTUgsU0FBU0ksS0FBSztBQUNqQyxjQUFNQyxnQkFDSkYsS0FBS0csV0FBVyxZQUNYLHNCQUFxQkgsS0FBS2UsU0FBVSw4QkFBNkJmLEtBQUtnQix3QkFBeUIsS0FDaEdoQixLQUFLSTtBQUNYLGVBQU9GO0FBQUFBLE1BQ1Q7QUFBTyxlQUFPO0FBQUEsSUFDaEIsU0FBU0csT0FBTztBQUNkLGFBQU8sc0RBQXNEQTtBQUFBQSxJQUMvRDtBQUFBLEVBQ0Y7QUFLQTFDLFlBQVUsTUFBTTtBQUNkRyxvQkFBZ0IsWUFBWWtCLGNBQWM7QUFDMUNsQixvQkFBZ0IsUUFBUXlCLFVBQVU7QUFDbEN6QixvQkFBZ0IsUUFBUTRCLFVBQVU7QUFDbEM1QixvQkFBZ0IsUUFBUXdDLFVBQVU7QUFDbEN4QyxvQkFBZ0IsVUFBVXlDLFlBQVk7QUFDdEN6QyxvQkFBZ0IsYUFBYThDLGVBQWU7QUFDNUM5QyxvQkFBZ0IsWUFBWVAsY0FBYztBQUMxQ08sb0JBQWdCLFlBQVlOLGNBQWM7QUFDMUNNLG9CQUFnQixjQUFjTCxnQkFBZ0I7QUFDOUNLLG9CQUFnQixpQkFBaUJKLG1CQUFtQjtBQUFBLEVBQ3RELEdBQUcsRUFBRTtBQU9MLGlCQUFldUQsZUFDYjlCLGNBQ0FGLE9BQ2lCO0FBQ2pCLFVBQU1qQixPQUFPSixnQkFBZ0JzRCxJQUFJL0IsWUFBVztBQUU1QyxRQUFJbkIsTUFBTTtBQUNSLFVBQUk7QUFFRixjQUFNbUMsU0FBUyxNQUFNbkMsS0FBS2lCLEtBQUk7QUFDOUIsZUFBT2tCO0FBQUFBLE1BQ1QsU0FBU0UsT0FBTztBQUNkLGVBQVEsNEJBQTJCQSxLQUFNO0FBQUEsTUFDM0M7QUFBQSxJQUNGLE9BQU87QUFDTCxhQUFRLHNCQUFxQmxCLFlBQVk7QUFBQSxJQUMzQztBQUFBLEVBQ0Y7QUFNQSxXQUFTZ0MsYUFBYTlDLGdCQUF1QjtBQUMzQyxVQUFNK0MsaUJBQWlCL0MsZUFBY3VCLEtBQUs7QUFDMUMsUUFBSXdCLG1CQUFtQixJQUFJO0FBQ3pCQyxZQUFNLHlCQUF5QjtBQUMvQjtBQUFBLElBQ0Y7QUFHQSxVQUFNcEMsUUFBT21DLGVBQWVFLE1BQU0sS0FBSztBQUV2Q0wsbUJBQWVoQyxNQUFLLENBQUMsR0FBR0EsTUFBS3NDLE1BQU0sQ0FBQyxDQUFDLEVBQUVDLEtBQU1yQixZQUFXO0FBQ3REckIsMEJBQW9CVCxnQkFBZThCLE1BQU07QUFDekMzQixlQUFTRCxRQUFRLENBQUM7QUFBQSxJQUNwQixDQUFDO0FBRURELHFCQUFpQixFQUFFO0FBQUEsRUFDckI7QUFRQSxXQUFTbUQsaUJBQWlCQyxHQUF3QjtBQUNoRCxRQUFJQSxFQUFFQyxRQUFRLFNBQVM7QUFDckJSLG1CQUFhOUMsYUFBYTtBQUFBLElBQzVCO0FBQUEsRUFDRjtBQUtBVixZQUFVLE1BQU07QUFDZCxVQUFNaUUsaUJBQWlCQSxDQUFDRixNQUFxQjtBQUMzQyxVQUFJQSxFQUFFQyxRQUFRLE9BQU9ELEVBQUVHLFNBQVM7QUFDOUIsY0FBTUMsZUFBZUMsU0FBU0MsY0FBYyxtQkFBbUI7QUFDL0QsWUFBSUYsZ0JBQWdCQSx3QkFBd0JHO0FBQzFDSCx1QkFBYUksTUFBTTtBQUFBLE1BQ3ZCO0FBQUEsSUFDRjtBQUVBSCxhQUFTSSxpQkFBaUIsV0FBV1AsY0FBYztBQUVuRCxXQUFPLE1BQU07QUFDWEcsZUFBU0ssb0JBQW9CLFdBQVdSLGNBQWM7QUFBQSxJQUN4RDtBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBSUwsU0FDRSx1QkFBQyxTQUFJLFdBQVUsY0FBYSxhQUFVLFVBQVMsY0FBWTdDLFdBQ3pEO0FBQUEsMkJBQUMsY0FDQztBQUFBLDZCQUFDLFlBQU8sZ0NBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QjtBQUFBLE1BQ3hCLHVCQUFDLG1CQUNDLE9BQU9WLGVBQ1AsVUFBVUMsa0JBQ1YsV0FBVyx5Q0FDWCxXQUFXbUQsb0JBSmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUk4QjtBQUFBLFNBTmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRQTtBQUFBLElBQ0EsdUJBQUMsWUFBTyxTQUFTLE1BQU1OLGFBQWE5QyxhQUFhLEdBQUcsc0JBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEQ7QUFBQSxPQVY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBV0E7QUFFSjtBQUFDRCxHQTlRZUYsV0FBUztBQUFBbUUsS0FBVG5FO0FBQVMsSUFBQW1FO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkNvbnRyb2xsZWRJbnB1dCIsImhhbmRsZU1vY2tMb2FkIiwiaGFuZGxlTW9ja1ZpZXciLCJoYW5kbGVNb2NrU2VhcmNoIiwiaGFuZGxlTW9ja0Jyb2FkYmFuZCIsInVzZUVmZmVjdCIsImNvbW1hbmRSZWdpc3RyeSIsIk1hcCIsInJlZ2lzdGVyQ29tbWFuZCIsImNvbW1hbmQiLCJmdW5jIiwic2V0IiwiUkVQTElucHV0IiwicHJvcHMiLCJfcyIsImNvbW1hbmRTdHJpbmciLCJzZXRDb21tYW5kU3RyaW5nIiwiY291bnQiLCJzZXRDb3VudCIsIm1vZGUiLCJzZXRNb2RlIiwiaGlzdG9yeSIsInNldEhpc3RvcnkiLCJjb21tYW5kUmVzdWx0TWFwIiwidXBkYXRlQ29tbWFuZFJlc3VsdCIsImFyaWFMYWJlbCIsImhhbmRsZVJlZ2lzdGVyIiwiYXJncyIsImxlbmd0aCIsImNvbW1hbmROYW1lIiwidG9FeGVjdXRlIiwiaGFzIiwiZXZhbCIsImhhbmRsZU1vZGUiLCJ2YWxpZE1vZGVzIiwiaW5jbHVkZXMiLCJoYW5kbGVMb2FkIiwiZmlsZXBhdGgiLCJ0cmltIiwicmVzcG9uc2UiLCJmZXRjaCIsIm9rIiwiZGF0YSIsImpzb24iLCJyZXN1bHRNZXNzYWdlIiwicmVzdWx0IiwiZXJyb3JfbWVzc2FnZSIsImVycm9yIiwiaGFuZGxlVmlldyIsImhhbmRsZVNlYXJjaCIsImhhc0hlYWRlcnMiLCJ2YWx1ZSIsInJlcGxhY2UiLCJjb2x1bW5JZCIsImhhbmRsZUJyb2FkYmFuZCIsInN0YXRlIiwiY291bnR5IiwiZGF0ZV90aW1lIiwiYnJvYWRiYW5kX2FjY2Vzc19wZXJjZW50IiwiZXhlY3V0ZUNvbW1hbmQiLCJnZXQiLCJoYW5kbGVTdWJtaXQiLCJ0cmltbWVkQ29tbWFuZCIsImFsZXJ0Iiwic3BsaXQiLCJzbGljZSIsInRoZW4iLCJoYW5kbGVFbnRlclByZXNzIiwiZSIsImtleSIsImhhbmRsZUtleVByZXNzIiwiY3RybEtleSIsImlucHV0RWxlbWVudCIsImRvY3VtZW50IiwicXVlcnlTZWxlY3RvciIsIkhUTUxJbnB1dEVsZW1lbnQiLCJmb2N1cyIsImFkZEV2ZW50TGlzdGVuZXIiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSRVBMSW5wdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL3N0eWxlcy9tYWluLmNzc1wiO1xuaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgQ29udHJvbGxlZElucHV0IH0gZnJvbSBcIi4vQ29udHJvbGxlZElucHV0XCI7XG5pbXBvcnQgeyBIaXN0b3J5SXRlbSB9IGZyb20gXCIuLi90eXBlcy9IaXN0b3J5SXRlbVwiO1xuaW1wb3J0IHsgUkVQTEZ1bmN0aW9uIH0gZnJvbSBcIi4uL3R5cGVzL1JFUExGdW5jdGlvblwiO1xuaW1wb3J0IHsgaGFuZGxlTW9ja0xvYWQsIGhhbmRsZU1vY2tWaWV3LCBoYW5kbGVNb2NrU2VhcmNoLCBoYW5kbGVNb2NrQnJvYWRiYW5kfSBcbmZyb20gXCIuL01vY2tlZFJFUExGdW5jdGlvbnNcIlxuaW1wb3J0IHsgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG4vKipcbiAqIE1hcCBzdG9yaW5nIHJlZ2lzdGVyZWQgY29tbWFuZHNcbiAqL1xuY29uc3QgY29tbWFuZFJlZ2lzdHJ5ID0gbmV3IE1hcDxzdHJpbmcsIFJFUExGdW5jdGlvbj4oKTtcblxuLyoqXG4gKiBIZWxwZXIgZnVuY3Rpb24gcmVzcG9uc2libGUgZm9yIHJlZ2lzdGVyaW5nIGNvbW1hbmRzXG4gKiBAcGFyYW0ge3N0cmluZ30gY29tbWFuZCAtIFRoZSBuYW1lIG9mIHRoZSBjb21tYW5kIHRvIGJlIHJlZ2lzdGVyZWRcbiAqIEBwYXJhbSB7UkVQTEZ1bmN0aW9ufSBmdW5jIC0gVGhlIGZ1bmN0aW9uIHRvIGJlIGV4ZWN1dGVkIHVwb24gY29tbWFuZCBjYWxsXG4gKi9cbmZ1bmN0aW9uIHJlZ2lzdGVyQ29tbWFuZChjb21tYW5kOiBzdHJpbmcsIGZ1bmM6IFJFUExGdW5jdGlvbikge1xuICBjb21tYW5kUmVnaXN0cnkuc2V0KGNvbW1hbmQsIGZ1bmMpO1xufVxuXG4vKipcbiAqIFByb3BzIGZvciB0aGUgUkVQTElucHV0UHJvcHMgY29tcG9uZW50XG4gKi9cbmludGVyZmFjZSBSRVBMSW5wdXRQcm9wcyB7XG4gIGhpc3Rvcnk6IEhpc3RvcnlJdGVtW107XG4gIHNldEhpc3Rvcnk6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPEhpc3RvcnlJdGVtW10+PjtcbiAgbW9kZTogc3RyaW5nO1xuICBzZXRNb2RlOiAobmV3TW9kZTogc3RyaW5nKSA9PiB2b2lkO1xuICBjb21tYW5kUmVzdWx0TWFwOiBNYXA8SGlzdG9yeUl0ZW0sIFtbXV0gfCBzdHJpbmc+O1xuICB1cGRhdGVDb21tYW5kUmVzdWx0OiAoY29tbWFuZDogc3RyaW5nLCBvdXRwdXQ6IFtbXV0gfCBzdHJpbmcpID0+IHZvaWQ7XG4gIGFyaWFMYWJlbDogc3RyaW5nO1xufVxuXG4vKipcbiAqIFJlYWN0IGNvbXBvbmVudCByZXNwb25zaWJsZSBmb3IgaGFuZGxpbmcgdXNlciBpbnB1dCBhbmQgZXhlY3V0aW5nIGNvbW1hbmRzXG4gKiBAcGFyYW0ge1JFUExJbnB1dFByb3BzfSBwcm9wcyAtIFRoZSBwcm9wZXJ0aWVzIHJlcXVpcmVkIGZvciByZW5kZXJpbmcgdGhlIGNvbXBvbmVudFxuICovXG5leHBvcnQgZnVuY3Rpb24gUkVQTElucHV0KHByb3BzOiBSRVBMSW5wdXRQcm9wcykge1xuICBjb25zdCBbY29tbWFuZFN0cmluZywgc2V0Q29tbWFuZFN0cmluZ10gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuICBjb25zdCBbY291bnQsIHNldENvdW50XSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG4gIGNvbnN0IHtcbiAgICBtb2RlLFxuICAgIHNldE1vZGUsXG4gICAgaGlzdG9yeSxcbiAgICBzZXRIaXN0b3J5LFxuICAgIGNvbW1hbmRSZXN1bHRNYXAsXG4gICAgdXBkYXRlQ29tbWFuZFJlc3VsdCxcbiAgICBhcmlhTGFiZWwsXG4gIH0gPSBwcm9wcztcblxuICAvKipcbiAgICogUkVQTEZ1bmN0aW9uIGhhbmRsaW5nIHRoZSByZWdpc3RyYXRpb24gb2YgYSB1c2VyLXNwZWNpZmllZCBjb21tYW5kXG4gICAqIEBwYXJhbSB7c3RyaW5nW119IGFyZ3MgLSBEZXRhaWxzIG9mIGEgdG8tYmUtcmVnaXN0ZXJlZCBmdW5jdGlvbiAoY29tbWFuZE5hbWUsIGZ1bmN0aW9uIGV4ZWN1dGVkIHVwb24gY29tbWFuZClcbiAgICovXG4gIGNvbnN0IGhhbmRsZVJlZ2lzdGVyOiBSRVBMRnVuY3Rpb24gPSBhc3luYyAoXG4gICAgYXJnczogc3RyaW5nW11cbiAgKTogUHJvbWlzZTxzdHJpbmc+ID0+IHtcbiAgICBpZiAoYXJncy5sZW5ndGggIT09IDIpIHtcbiAgICAgIHJldHVybiBcIkludmFsaWQgdXNhZ2Ugb2YgJ3JlZ2lzdGVyJyBjb21tYW5kLiBVc2FnZTogcmVnaXN0ZXIgPGNvbW1hbmROYW1lPiA8ZnVuY3Rpb25Ub0V4ZWN1dGU+XCI7XG4gICAgfVxuICAgIGNvbnN0IGNvbW1hbmROYW1lID0gYXJnc1swXTtcbiAgICBjb25zdCB0b0V4ZWN1dGUgPSBhcmdzWzFdO1xuICAgIGlmIChjb21tYW5kUmVnaXN0cnkuaGFzKGNvbW1hbmROYW1lKSkge1xuICAgICAgcmV0dXJuIFwiQ29tbWFuZDogXCIgKyBjb21tYW5kTmFtZSArIFwiIGlzIGFscmVhZHkgcmVnaXN0ZXJlZFwiO1xuICAgIH0gZWxzZSB7XG4gICAgICByZWdpc3RlckNvbW1hbmQoY29tbWFuZE5hbWUsIGV2YWwodG9FeGVjdXRlKSk7XG4gICAgICByZXR1cm4gXCJDb21tYW5kIHJlZ2lzdGVyZWQ6IFwiICsgY29tbWFuZE5hbWU7XG4gICAgfVxuICB9O1xuXG4gIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvKipcbiAgICogRnVuY3Rpb24gaGFuZGxpbmcgbW9kZSBjaGFuZ2VzIG9mIHRoZSBSRVBMIGludGVyZmFjZVxuICAgKiBAcGFyYW0ge3N0cmluZ1tdfSBhcmdzIC0gVGhlIG5ldyBtb2RlIHRvIHNldFxuICAgKi9cbiAgY29uc3QgaGFuZGxlTW9kZTogUkVQTEZ1bmN0aW9uID0gYXN5bmMgKGFyZ3M6IHN0cmluZ1tdKTogUHJvbWlzZTxzdHJpbmc+ID0+IHtcbiAgICBjb25zdCB2YWxpZE1vZGVzID0gW1wiYnJpZWZcIiwgXCJ2ZXJib3NlXCJdO1xuICAgIGlmIChhcmdzLmxlbmd0aCAhPT0gMSkge1xuICAgICAgcmV0dXJuIFwiSW52YWxpZCB1c2FnZSBvZiAnbW9kZScgY29tbWFuZC4gVXNhZ2U6IG1vZGUgPG5ld01vZGU+XCI7XG4gICAgfVxuICAgIGlmICh2YWxpZE1vZGVzLmluY2x1ZGVzKGFyZ3NbMF0pKSB7XG4gICAgICBzZXRNb2RlKGFyZ3NbMF0pO1xuICAgICAgcmV0dXJuIFwiTW9kZSBjaGFuZ2VkIHRvIFwiICsgYXJnc1swXTtcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIFwiSW52YWxpZCBtb2RlOiBcIiArIGFyZ3NbMF0gKyBcIi4gVXNlIGJyaWVmIG9yIHZlcmJvc2VcIjtcbiAgICB9XG4gIH07XG5cbiAgLyoqXG4gICAqIEZ1bmN0aW9uIGhhbmRsaW5nIGxvYWRpbmcgdGhlIGZpbGVcbiAgICogQHBhcmFtIHtzdHJpbmdbXX0gYXJncyAtIFRoZSBmaWxlIHBhdGggb2YgYSBmaWxlIHRvIGJlIGxvYWRlZCAobXVzdCBiZSB3aXRoaW4gdGhlIGRhdGEgZGlyZWN0b3J5KVxuICAgKi9cbiAgY29uc3QgaGFuZGxlTG9hZDogUkVQTEZ1bmN0aW9uID0gYXN5bmMgKGFyZ3M6IHN0cmluZ1tdKTogUHJvbWlzZTxzdHJpbmc+ID0+IHtcbiAgICBpZiAoYXJncy5sZW5ndGggIT09IDEpIHtcbiAgICAgIHJldHVybiBcIkludmFsaWQgdXNhZ2Ugb2YgJ2xvYWQnIGNvbW1hbmQuIFVzYWdlOiBsb2FkIDxVUkw+XCI7XG4gICAgfVxuICAgIGNvbnN0IGZpbGVwYXRoID0gYXJnc1swXS50cmltKCk7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goXG4gICAgICAgIGBodHRwOi8vbG9jYWxob3N0OjMyMzIvbG9hZGNzdj9maWxlcGF0aD1yZXBsL3NyYy9iYWNrZW5kLyR7ZmlsZXBhdGh9YFxuICAgICAgKTtcbiAgICAgIGlmIChyZXNwb25zZS5vaykge1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBjb25zdCByZXN1bHRNZXNzYWdlID1cbiAgICAgICAgICBkYXRhLnJlc3VsdCA9PT0gXCJzdWNjZXNzXCJcbiAgICAgICAgICAgID8gXCJGaWxlIFwiICsgZmlsZXBhdGggKyBcIiBsb2FkZWQgc3VjY2Vzc2Z1bGx5XCJcbiAgICAgICAgICAgIDogZGF0YS5lcnJvcl9tZXNzYWdlO1xuICAgICAgICByZXR1cm4gcmVzdWx0TWVzc2FnZTtcbiAgICAgIH0gZWxzZSByZXR1cm4gXCJGYWlsZWQgdG8gZmV0Y2ggZGF0YSBmcm9tIHRoZSBiYWNrZW5kXCI7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIC8vIEltcGxlbWVudCB0aGUgbG9naWMgdG8gbG9hZCB0aGUgZmlsZSBiYXNlZCBvbiB0aGUgcHJvdmlkZWQgJ3VybCcuXG4gICAgICAvLyBSZXR1cm4gYW4gYXBwcm9wcmlhdGUgcmVzdWx0IG1lc3NhZ2UuXG4gICAgICByZXR1cm4gXCJBbiBlcnJvciBvY3VycmVkIHdoaWxlIGxvYWRpbmcgdGhlIGZpbGU6IFwiICsgZXJyb3I7XG4gICAgfVxuICB9O1xuXG4gIC8qKlxuICAgKiBGdW5jdGlvbiBoYW5kbGluZyB2aWV3aW5nIHRoZSBsb2FkZWQgZGF0YXNldFxuICAgKiBAcGFyYW0ge3N0cmluZ1tdfSBhcmdzIC0gTm9uZSAoZW1wdHkpXG4gICAqL1xuICBjb25zdCBoYW5kbGVWaWV3OiBSRVBMRnVuY3Rpb24gPSBhc3luYyAoYXJnczogc3RyaW5nW10pOiBQcm9taXNlPHN0cmluZz4gPT4ge1xuICAgIGlmIChhcmdzLmxlbmd0aCAhPT0gMCkge1xuICAgICAgcmV0dXJuIFwiSW52YWxpZCB1c2FnZSBvZiAndmlldycgY29tbWFuZC4gVXNhZ2U6IHZpZXdcIjtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goXCJodHRwOi8vbG9jYWxob3N0OjMyMzIvdmlld2NzdlwiKTtcbiAgICAgIGlmIChyZXNwb25zZS5vaykge1xuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBjb25zdCByZXN1bHRNZXNzYWdlID1cbiAgICAgICAgICBkYXRhLnJlc3VsdCA9PT0gXCJzdWNjZXNzXCIgPyBkYXRhLmRhdGEgOiBkYXRhLmVycm9yX21lc3NhZ2U7XG4gICAgICAgIHJldHVybiByZXN1bHRNZXNzYWdlO1xuICAgICAgfSBlbHNlIHJldHVybiBcIkZhaWxlZCB0byBmZXRjaCBkYXRhIGZyb20gdGhlIGJhY2tlbmRcIjtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgcmV0dXJuIFwiQW4gZXJyb3Igb2NjdXJyZWQgd2hpbGUgdmlld2luZyB0aGUgZmlsZTogXCIgKyBlcnJvcjtcbiAgICB9XG4gIH07XG5cbiAgLyoqXG4gICAqIEZ1bmN0aW9uIGhhbmRsaW5nIHNlYXJjaGluZyB3aXRoaW4gdGhlIGxvYWRlZCBkYXRhc2V0XG4gICAqIEBwYXJhbSB7c3RyaW5nW119IGFyZ3MgLSBUaGUgc2VhcmNoIHF1ZXJ5IHBhcmFtZXRlcnNcbiAgICovXG4gIGNvbnN0IGhhbmRsZVNlYXJjaDogUkVQTEZ1bmN0aW9uID0gYXN5bmMgKFxuICAgIGFyZ3M6IHN0cmluZ1tdXG4gICk6IFByb21pc2U8c3RyaW5nPiA9PiB7XG4gICAgaWYgKGFyZ3MubGVuZ3RoICE9PSAzKSB7XG4gICAgICByZXR1cm4gXCJJbnZhbGlkIHNlYXJjaCBjb21tYW5kLiBVc2FnZTogc2VhcmNoIDxoYXNIZWFkZXJzPiA8dmFsdWU+IDxjb2x1bW5JZD5cIjtcbiAgICB9XG4gICAgY29uc3QgaGFzSGVhZGVycyA9IGFyZ3NbMF07XG4gICAgY29uc3QgdmFsdWUgPSBhcmdzWzFdLmluY2x1ZGVzKFwiJVwiKVxuICAgICAgPyBhcmdzWzFdLnJlcGxhY2UoXCIlXCIsIFwiJTI1XCIpLnJlcGxhY2UoL18vZywgXCIgXCIpXG4gICAgICA6IGFyZ3NbMV0ucmVwbGFjZSgvXy9nLCBcIiBcIik7XG4gICAgY29uc3QgY29sdW1uSWQgPSBhcmdzWzJdLnJlcGxhY2UoL18vZywgXCIgXCIpO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goXG4gICAgICAgIGBodHRwOi8vbG9jYWxob3N0OjMyMzIvc2VhcmNoY3N2P2hlYWRlcnM9JHtoYXNIZWFkZXJzfSZ2YWx1ZT0ke3ZhbHVlfSZjb2xpZD0ke2NvbHVtbklkfWBcbiAgICAgICk7XG4gICAgICBpZiAocmVzcG9uc2Uub2spIHtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgY29uc3QgcmVzdWx0TWVzc2FnZSA9XG4gICAgICAgICAgZGF0YS5yZXN1bHQgPT09IFwic3VjY2Vzc1wiID8gZGF0YS5kYXRhIDogZGF0YS5lcnJvcl9tZXNzYWdlO1xuICAgICAgICByZXR1cm4gcmVzdWx0TWVzc2FnZTtcbiAgICAgIH0gZWxzZSByZXR1cm4gXCJGYWlsZWQgdG8gZmV0Y2ggZGF0YSBmcm9tIHRoZSBiYWNrZW5kXCI7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHJldHVybiBcIkFuIGVycm9yIG9jY3VycmVkIHdoaWxlIHNlYXJjaGluZyB0aHJvdWdoIHRoZSBmaWxlOiBcIiArIGVycm9yO1xuICAgIH1cbiAgfTtcblxuICAvKipcbiAgICogRnVuY3Rpb24gaGFuZGxpbmcgcmV0cmlldmluZyBicm9hZGJhbmQgYWNjZXNzIHBlcmNlbnRhZ2VcbiAgICogQHBhcmFtIHtzdHJpbmdbXX0gYXJncyAtIFRoZSBicm9hZGJhbmQgcXVlcnkgcGFyYW1ldGVyc1xuICAgKi9cbiAgY29uc3QgaGFuZGxlQnJvYWRiYW5kOiBSRVBMRnVuY3Rpb24gPSBhc3luYyAoXG4gICAgYXJnczogc3RyaW5nW11cbiAgKTogUHJvbWlzZTxzdHJpbmc+ID0+IHtcbiAgICBpZiAoYXJncy5sZW5ndGggIT09IDIpIHtcbiAgICAgIHJldHVybiBcIkludmFsaWQgYnJvYWRiYW5kIHJldHJpZXZhbCBjb21tYW5kLiBVc2FnZTogYnJvYWRiYW5kIDxzdGF0ZT4gPGNvdW50eT5cIjtcbiAgICB9XG4gICAgY29uc3Qgc3RhdGUgPSBhcmdzWzBdLnJlcGxhY2UoL18vZywgXCIgXCIpO1xuICAgIGNvbnN0IGNvdW50eSA9IGFyZ3NbMV0ucmVwbGFjZSgvXy9nLCBcIiBcIik7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcbiAgICAgICAgYGh0dHA6Ly9sb2NhbGhvc3Q6MzIzMi9icm9hZGJhbmQ/c3RhdGU9JHtzdGF0ZX0mY291bnR5PSR7Y291bnR5fWBcbiAgICAgICk7XG4gICAgICBpZiAocmVzcG9uc2Uub2spIHtcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgICAgICAgY29uc3QgcmVzdWx0TWVzc2FnZSA9XG4gICAgICAgICAgZGF0YS5yZXN1bHQgPT09IFwic3VjY2Vzc1wiXG4gICAgICAgICAgICA/IGB0aW1lIG9mIHJldHJpZXZhbDogJHtkYXRhLmRhdGVfdGltZX0gYnJvYWRiYW5kIGFjY2VzcyBwZXJjZW50OiAke2RhdGEuYnJvYWRiYW5kX2FjY2Vzc19wZXJjZW50fWBcbiAgICAgICAgICAgIDogZGF0YS5lcnJvcl9tZXNzYWdlO1xuICAgICAgICByZXR1cm4gcmVzdWx0TWVzc2FnZTtcbiAgICAgIH0gZWxzZSByZXR1cm4gXCJGYWlsZWQgdG8gZmV0Y2ggZGF0YSBmcm9tIHRoZSBiYWNrZW5kXCI7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIHJldHVybiBcIkFuIGVycm9yIG9jY3VycmVkIHdoaWxlIGZldGNoaW5nIGJyb2FkYmFuZCBkYXRhOiBcIiArIGVycm9yO1xuICAgIH1cbiAgfTtcbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBGdW5jdGlvbnMgcmVnaXN0ZXJlZCB1cG9uIGNvbXBvbmVudCBtb3VudFxuICAgKi9cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICByZWdpc3RlckNvbW1hbmQoXCJyZWdpc3RlclwiLCBoYW5kbGVSZWdpc3Rlcik7XG4gICAgcmVnaXN0ZXJDb21tYW5kKFwibW9kZVwiLCBoYW5kbGVNb2RlKTtcbiAgICByZWdpc3RlckNvbW1hbmQoXCJsb2FkXCIsIGhhbmRsZUxvYWQpO1xuICAgIHJlZ2lzdGVyQ29tbWFuZChcInZpZXdcIiwgaGFuZGxlVmlldyk7XG4gICAgcmVnaXN0ZXJDb21tYW5kKFwic2VhcmNoXCIsIGhhbmRsZVNlYXJjaCk7XG4gICAgcmVnaXN0ZXJDb21tYW5kKFwiYnJvYWRiYW5kXCIsIGhhbmRsZUJyb2FkYmFuZCk7XG4gICAgcmVnaXN0ZXJDb21tYW5kKFwibW9ja2xvYWRcIiwgaGFuZGxlTW9ja0xvYWQpO1xuICAgIHJlZ2lzdGVyQ29tbWFuZChcIm1vY2t2aWV3XCIsIGhhbmRsZU1vY2tWaWV3KTtcbiAgICByZWdpc3RlckNvbW1hbmQoXCJtb2Nrc2VhcmNoXCIsIGhhbmRsZU1vY2tTZWFyY2gpO1xuICAgIHJlZ2lzdGVyQ29tbWFuZChcIm1vY2ticm9hZGJhbmRcIiwgaGFuZGxlTW9ja0Jyb2FkYmFuZCk7XG4gIH0sIFtdKTtcblxuICAvKipcbiAgICogSGVscGVyIGZ1bmN0aW9uIGZvciBleGVjdXRpbmcgdGhlIGNvbW1hbmQgdXBvbiBpbnB1dCBzdWJtaXNzaW9uXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBjb21tYW5kTmFtZSAtIE5hbWUgb2YgdGhlIGNvbW1hbmRcbiAgICogQHBhcmFtIHtzdHJpbmdbXX0gYXJncyAtIEFyZ3VtZW50cyBmb3IgdGhlIHRvLWJlLWV4ZWN1dGVkIGZ1bmN0aW9uIGFzc2lnbmVkIHRvIHRoZSBjb21tYW5kXG4gICAqL1xuICBhc3luYyBmdW5jdGlvbiBleGVjdXRlQ29tbWFuZChcbiAgICBjb21tYW5kTmFtZTogc3RyaW5nLFxuICAgIGFyZ3M6IHN0cmluZ1tdXG4gICk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3QgZnVuYyA9IGNvbW1hbmRSZWdpc3RyeS5nZXQoY29tbWFuZE5hbWUpO1xuXG4gICAgaWYgKGZ1bmMpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIC8vIEV4ZWN1dGUgdGhlIHJlZ2lzdGVyZWQgZnVuY3Rpb24gYW5kIHBhc3MgdGhlIGFyZ3VtZW50cywgZXhjbHVkaW5nIHRoZSBjb21tYW5kIGl0c2VsZlxuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBmdW5jKGFyZ3MpO1xuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIGBFcnJvciBleGVjdXRpbmcgY29tbWFuZC4gJHtlcnJvcn1gO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gYENvbW1hbmQgbm90IGZvdW5kOiAke2NvbW1hbmROYW1lfS4gSW5wdXQgXCJyZWdpc3RlciA8Y29tbWFuZE5hbWU+IDxmdW5jdGlvbj5cIiB0byByZWdpc3RlciBuZXcgY29tbWFuZGA7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEZ1bmN0aW9uIHRyaWdnZXJlZCB3aGVuIHRoZSBcIlN1Ym1pdFwiIGJ1dHRvbiBpcyBjbGlja2VkIHRvIHByb2Nlc3MgdGhlIHVzZXIncyBjb21tYW5kXG4gICAqIEBwYXJhbSB7c3RyaW5nfSBjb21tYW5kU3RyaW5nIC0gVGhlIHdob2xlIHVzZXIgaW5wdXRcbiAgICovXG4gIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nOiBzdHJpbmcpIHtcbiAgICBjb25zdCB0cmltbWVkQ29tbWFuZCA9IGNvbW1hbmRTdHJpbmcudHJpbSgpO1xuICAgIGlmICh0cmltbWVkQ29tbWFuZCA9PT0gXCJcIikge1xuICAgICAgYWxlcnQoXCJDb21tYW5kIGNhbm5vdCBiZSBlbXB0eVwiKTtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICAvLyBhcnJheSBvZiBhbGwgd29yZHMgZW50ZXJlZCBieSB1c2VyIGluIHRoZSBjb21tYW5kIGlucHV0XG4gICAgY29uc3QgYXJncyA9IHRyaW1tZWRDb21tYW5kLnNwbGl0KC9cXHMrLyk7XG4gICAgLy8gYXJnc1swXSBpcyB0aGUgY29tbWFuZCBuYW1lLCBhcmdzLnNsaWNlKDEpIGlzIGFuIGFycmF5IG9mIGV2ZXJ5dGhpbmcgRVhDRVBUIGZvciB0aGUgY29tbWFuZCBuYW1lXG4gICAgZXhlY3V0ZUNvbW1hbmQoYXJnc1swXSwgYXJncy5zbGljZSgxKSkudGhlbigocmVzdWx0KSA9PiB7XG4gICAgICB1cGRhdGVDb21tYW5kUmVzdWx0KGNvbW1hbmRTdHJpbmcsIHJlc3VsdCk7XG4gICAgICBzZXRDb3VudChjb3VudCArIDEpO1xuICAgIH0pO1xuXG4gICAgc2V0Q29tbWFuZFN0cmluZyhcIlwiKTtcbiAgfVxuXG4gIC8vQWxsIGtleWJvYXJkIHNob3J0Y3V0cyBoZXJlXG4gIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8qKlxuICAgKiBIYW5kbGVzIGtleWJvYXJkIHNob3J0Y3V0IHRvIHN1Ym1pdCBieSBwcmVzc2luZyBFbnRlciBpbiBjb21tYW5kIGJveFxuICAgKiBAcGFyYW0gZSBrZXlib2FyZCBldmVudCBvZiBwcmVzc2luZyBFbnRlciBrZXlcbiAgICovXG4gIGZ1bmN0aW9uIGhhbmRsZUVudGVyUHJlc3MoZTogUmVhY3QuS2V5Ym9hcmRFdmVudCkge1xuICAgIGlmIChlLmtleSA9PT0gXCJFbnRlclwiKSB7XG4gICAgICBoYW5kbGVTdWJtaXQoY29tbWFuZFN0cmluZyk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFdlYnBhZ2UgYWx3YXlzIGxpc3RlbnMgb3V0IGZvciBDdHJsK2IgdG8gbmF2aWdhdGUgY3Vyc29yIHRvIGNvbW1hbmQgYm94XG4gICAqL1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IGhhbmRsZUtleVByZXNzID0gKGU6IEtleWJvYXJkRXZlbnQpID0+IHtcbiAgICAgIGlmIChlLmtleSA9PT0gXCJiXCIgJiYgZS5jdHJsS2V5KSB7XG4gICAgICAgIGNvbnN0IGlucHV0RWxlbWVudCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCIucmVwbC1jb21tYW5kLWJveFwiKTtcbiAgICAgICAgaWYgKGlucHV0RWxlbWVudCAmJiBpbnB1dEVsZW1lbnQgaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KVxuICAgICAgICAgIGlucHV0RWxlbWVudC5mb2N1cygpO1xuICAgICAgfVxuICAgIH07XG5cbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKFwia2V5ZG93blwiLCBoYW5kbGVLZXlQcmVzcyk7XG5cbiAgICByZXR1cm4gKCkgPT4ge1xuICAgICAgZG9jdW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcihcImtleWRvd25cIiwgaGFuZGxlS2V5UHJlc3MpO1xuICAgIH07XG4gIH0sIFtdKTtcblxuICAvLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZXBsLWlucHV0XCIgYXJpYS1saXZlPVwicG9saXRlXCIgYXJpYS1sYWJlbD17YXJpYUxhYmVsfT5cbiAgICAgIDxmaWVsZHNldD5cbiAgICAgICAgPGxlZ2VuZD5FbnRlciBhIGNvbW1hbmQ6PC9sZWdlbmQ+XG4gICAgICAgIDxDb250cm9sbGVkSW5wdXRcbiAgICAgICAgICB2YWx1ZT17Y29tbWFuZFN0cmluZ31cbiAgICAgICAgICBzZXRWYWx1ZT17c2V0Q29tbWFuZFN0cmluZ31cbiAgICAgICAgICBhcmlhTGFiZWw9e1wiQ29tbWFuZCBJbnB1dCBCb3ggdG8gdHlwZSBpbiBjb21tYW5kc1wifVxuICAgICAgICAgIG9uS2V5RG93bj17aGFuZGxlRW50ZXJQcmVzc31cbiAgICAgICAgLz5cbiAgICAgIDwvZmllbGRzZXQ+XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IGhhbmRsZVN1Ym1pdChjb21tYW5kU3RyaW5nKX0+U3VibWl0PC9idXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy96ZHppbG93c2thL0Rlc2t0b3AvdW5pdmVyc2l0eS95ZWFyIDIvY3MwMzIwL3JlcGwtanpkemlsb3ctcHJsYWtzaG0vcmVwbC9zcmMvZnJvbnRlbmQvY29tcG9uZW50cy9SRVBMSW5wdXQudHN4In0=