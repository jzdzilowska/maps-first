import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/frontend/components/REPL.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=0eb6d985"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/REPL.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=0eb6d985"; const useState = __vite__cjsImport3_react["useState"];
import "/src/frontend/styles/main.css";
import { REPLHistory } from "/src/frontend/components/REPLHistory.tsx";
import { REPLInput } from "/src/frontend/components/REPLInput.tsx";
export default function REPL() {
  _s();
  const [history, setHistory] = useState([]);
  const [mode, setMode] = useState("brief");
  const [commandResultMap, setCommandResultMap] = useState(/* @__PURE__ */ new Map());
  function updateCommandResult(command, result) {
    const historyItem = {
      command,
      timestamp: (/* @__PURE__ */ new Date()).getTime()
    };
    commandResultMap.set(historyItem, result);
    setHistory((prevHistory) => [...prevHistory, historyItem]);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "repl", children: [
    /* @__PURE__ */ jsxDEV(REPLHistory, { commandHistory: history, mode, commandResultMap, ariaLabel: "History Log Display to show past commands inputted" }, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/REPL.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/REPL.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(REPLInput, { history, setHistory, mode, setMode, commandResultMap, updateCommandResult, ariaLabel: "Input Command Component to take in and process command inputs" }, void 0, false, {
      fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/REPL.tsx",
      lineNumber: 36,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/REPL.tsx",
    lineNumber: 33,
    columnNumber: 10
  }, this);
}
_s(REPL, "MI9yKj6bEoyKNR+lE9l8G06o4bw=");
_c = REPL;
var _c;
$RefreshReg$(_c, "REPL");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/zdzilowska/Desktop/university/year 2/cs0320/repl-jzdzilow-prlakshm/repl/src/frontend/components/REPL.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUNNOzs7Ozs7Ozs7Ozs7Ozs7OztBQWpDTixTQUFtQ0EsZ0JBQWdCO0FBQ25ELE9BQU87QUFDUCxTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsaUJBQWlCO0FBUzFCLHdCQUF3QkMsT0FBTztBQUFBQyxLQUFBO0FBQzdCLFFBQU0sQ0FBQ0MsU0FBU0MsVUFBVSxJQUFJTixTQUF3QixFQUFFO0FBQ3hELFFBQU0sQ0FBQ08sTUFBTUMsT0FBTyxJQUFJUixTQUFpQixPQUFPO0FBQ2hELFFBQU0sQ0FBQ1Msa0JBQWtCQyxtQkFBbUIsSUFBSVYsU0FBUyxvQkFBSVcsSUFBSSxDQUFDO0FBT2xFLFdBQVNDLG9CQUFvQkMsU0FBaUJDLFFBQXVCO0FBQ25FLFVBQU1DLGNBQTJCO0FBQUEsTUFDL0JGO0FBQUFBLE1BQ0FHLFlBQVcsb0JBQUlDLEtBQUssR0FBRUMsUUFBUTtBQUFBLElBQ2hDO0FBQ0FULHFCQUFpQlUsSUFBSUosYUFBYUQsTUFBTTtBQUN4Q1IsZUFBWWMsaUJBQWdCLENBQUMsR0FBR0EsYUFBYUwsV0FBVyxDQUFDO0FBQUEsRUFDM0Q7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxRQUNiO0FBQUEsMkJBQUMsZUFDQyxnQkFBZ0JWLFNBQ2hCLE1BQ0Esa0JBQ0EsV0FBVSx3REFKWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSWdFO0FBQUEsSUFFaEUsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUk7QUFBQSxJQUNKLHVCQUFDLGFBQ0MsU0FDQSxZQUNBLE1BQ0EsU0FDQSxrQkFDQSxxQkFDQSxXQUFVLG1FQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPMkU7QUFBQSxPQWY3RTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUJBO0FBRUo7QUFBQ0QsR0F2Q3VCRCxNQUFJO0FBQUFrQixLQUFKbEI7QUFBSSxJQUFBa0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiUkVQTEhpc3RvcnkiLCJSRVBMSW5wdXQiLCJSRVBMIiwiX3MiLCJoaXN0b3J5Iiwic2V0SGlzdG9yeSIsIm1vZGUiLCJzZXRNb2RlIiwiY29tbWFuZFJlc3VsdE1hcCIsInNldENvbW1hbmRSZXN1bHRNYXAiLCJNYXAiLCJ1cGRhdGVDb21tYW5kUmVzdWx0IiwiY29tbWFuZCIsInJlc3VsdCIsImhpc3RvcnlJdGVtIiwidGltZXN0YW1wIiwiRGF0ZSIsImdldFRpbWUiLCJzZXQiLCJwcmV2SGlzdG9yeSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUkVQTC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IFwiLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyBSRVBMSGlzdG9yeSB9IGZyb20gXCIuL1JFUExIaXN0b3J5XCI7XG5pbXBvcnQgeyBSRVBMSW5wdXQgfSBmcm9tIFwiLi9SRVBMSW5wdXRcIjtcbmltcG9ydCB7IEhpc3RvcnlJdGVtIH0gZnJvbSBcIi4uL3R5cGVzL0hpc3RvcnlJdGVtXCI7XG5cbi8qKlxuICogUmVhY3QgY29tcG9uZW50IGFsbG93aW5nIHVzZXJzIHRvIGlucHV0IGNvbW1hbmRzO1xuICogRGlzcGxheXMgY29ycmVzcG9uZGluZyBjb21tYW5kIGhpc3RvcnksIGFuZCBzaG93cyB0aGUgcmVzdWx0cyBvZiBlYWNoIGNvbW1hbmQuXG4gKiBEZXBlbmRpbmcgb24gdGhlIG1vZGUgc2VsZWN0ZWQsIGNhbiBkaXNwbGF5IGVpdGhlciBqdXN0IHRoZSBvdXRwdXQsXG4gKiBvciBib3RoIHRoZSB1c2VyJ3MgY29tbWFuZCBhbmQgdGhlIG91dHB1dC5cbiAqL1xuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUkVQTCgpIHtcbiAgY29uc3QgW2hpc3RvcnksIHNldEhpc3RvcnldID0gdXNlU3RhdGU8SGlzdG9yeUl0ZW1bXT4oW10pO1xuICBjb25zdCBbbW9kZSwgc2V0TW9kZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiYnJpZWZcIik7XG4gIGNvbnN0IFtjb21tYW5kUmVzdWx0TWFwLCBzZXRDb21tYW5kUmVzdWx0TWFwXSA9IHVzZVN0YXRlKG5ldyBNYXAoKSk7XG5cbiAgLyoqXG4gICAqIFVwZGF0ZSB0aGUgY29tbWFuZCByZXN1bHQgYW5kIGFkZCBpdCB0byB0aGUgY29tbWFuZCBoaXN0b3J5LlxuICAgKiBAcGFyYW0ge3N0cmluZ30gY29tbWFuZCAtIFRoZSB1c2VyJ3MgaW5wdXQgY29tbWFuZC5cbiAgICogQHBhcmFtIHtbW11dIHwgc3RyaW5nIH0gcmVzdWx0IC0gVGhlIHJlc3VsdCBvZiB0aGUgY29tbWFuZCBleGVjdXRpb24uXG4gICAqL1xuICBmdW5jdGlvbiB1cGRhdGVDb21tYW5kUmVzdWx0KGNvbW1hbmQ6IHN0cmluZywgcmVzdWx0OiBbW11dIHwgc3RyaW5nKSB7XG4gICAgY29uc3QgaGlzdG9yeUl0ZW06IEhpc3RvcnlJdGVtID0ge1xuICAgICAgY29tbWFuZDogY29tbWFuZCxcbiAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS5nZXRUaW1lKCksXG4gICAgfTtcbiAgICBjb21tYW5kUmVzdWx0TWFwLnNldChoaXN0b3J5SXRlbSwgcmVzdWx0KTtcbiAgICBzZXRIaXN0b3J5KChwcmV2SGlzdG9yeSkgPT4gWy4uLnByZXZIaXN0b3J5LCBoaXN0b3J5SXRlbV0pO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlcGxcIj5cbiAgICAgIDxSRVBMSGlzdG9yeVxuICAgICAgICBjb21tYW5kSGlzdG9yeT17aGlzdG9yeX1cbiAgICAgICAgbW9kZT17bW9kZX1cbiAgICAgICAgY29tbWFuZFJlc3VsdE1hcD17Y29tbWFuZFJlc3VsdE1hcH1cbiAgICAgICAgYXJpYUxhYmVsPVwiSGlzdG9yeSBMb2cgRGlzcGxheSB0byBzaG93IHBhc3QgY29tbWFuZHMgaW5wdXR0ZWRcIlxuICAgICAgLz5cbiAgICAgIDxocj48L2hyPlxuICAgICAgPFJFUExJbnB1dFxuICAgICAgICBoaXN0b3J5PXtoaXN0b3J5fVxuICAgICAgICBzZXRIaXN0b3J5PXtzZXRIaXN0b3J5fVxuICAgICAgICBtb2RlPXttb2RlfVxuICAgICAgICBzZXRNb2RlPXtzZXRNb2RlfVxuICAgICAgICBjb21tYW5kUmVzdWx0TWFwPXtjb21tYW5kUmVzdWx0TWFwfVxuICAgICAgICB1cGRhdGVDb21tYW5kUmVzdWx0PXt1cGRhdGVDb21tYW5kUmVzdWx0fVxuICAgICAgICBhcmlhTGFiZWw9XCJJbnB1dCBDb21tYW5kIENvbXBvbmVudCB0byB0YWtlIGluIGFuZCBwcm9jZXNzIGNvbW1hbmQgaW5wdXRzXCJcbiAgICAgIC8+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy96ZHppbG93c2thL0Rlc2t0b3AvdW5pdmVyc2l0eS95ZWFyIDIvY3MwMzIwL3JlcGwtanpkemlsb3ctcHJsYWtzaG0vcmVwbC9zcmMvZnJvbnRlbmQvY29tcG9uZW50cy9SRVBMLnRzeCJ9