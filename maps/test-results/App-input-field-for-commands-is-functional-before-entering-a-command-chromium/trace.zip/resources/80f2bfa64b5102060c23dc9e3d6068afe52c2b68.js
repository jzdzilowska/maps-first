import {
  require_react
} from "/node_modules/.vite/deps/chunk-UZX524IT.js?v=0eb6d985";
export default require_react();
//# sourceMappingURL=react.js.map
